package com.example.week3;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class Reservation extends AppCompatActivity implements ReservationFragment.ReservationListener {



    public static final String TAG = "demo";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.containerView, new ReservationFragment())
                .commit();
        Log.d(TAG, "ReservationFragment:onCreate: ");


    }

    @Override
    public void sendConfirmation(Confirmation confirmation) {
        Log.d(TAG, "sendConfirmation: " + confirmation);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containerView, ConfirmationFragment.newInstance(confirmation))
                .addToBackStack(null)
                .commit();


    }

    @Override
    public void sendUsername(String username) { Log.d(TAG, "sendUsername: " +username); }

    @Override
    public void sendPhone(String phone) { Log.d(TAG, "sendPhone: " +phone); }

    @Override
    public void sendEmail(String email) {
        Log.d(TAG, "sendEmail: " +email);
    }

    @Override
    public void sendDate(String date) {
        Log.d(TAG, "sendDate: " +date);
    }

    @Override
    public void sendTime(String time) {
        Log.d(TAG, "sendTime: " +time);
    }
}

