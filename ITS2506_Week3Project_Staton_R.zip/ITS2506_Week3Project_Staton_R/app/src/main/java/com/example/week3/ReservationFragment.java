package com.example.week3;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.week3.databinding.FragmentReservationBinding;

public class ReservationFragment extends Fragment {
    public static final String TAG = "demo";
    public ReservationFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    FragmentReservationBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentReservationBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Reservation Fragment");

        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = binding.editTextName.getText().toString();
                String phone = binding.editTextPhone.getText().toString();
                String email = binding.editTextEmail.getText().toString();
                String date = binding.editTextDate.getText().toString();
                String time = binding.editTextTime.getText().toString();

                mListener.sendUsername(name);
                mListener.sendPhone(phone);
                mListener.sendEmail(email);
                mListener.sendDate(date);
                mListener.sendTime(time);

                Confirmation confirmation = new Confirmation(name, phone, email, date, time);
                mListener.sendConfirmation(confirmation);

            }

        });
    }

    ReservationListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (ReservationListener) context;
    }

    //define interface
    public interface ReservationListener {
        void sendConfirmation(Confirmation confirmation);
        void sendUsername(String username);
        void sendPhone(String phone);
        void sendEmail(String email);
        void sendDate(String date);
        void sendTime(String time);
    }



}