package com.example.week3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.week3.databinding.FragmentConfirmationBinding;

public class ConfirmationFragment extends Fragment {

    private static final String ARG_PARAM_CONFIRMATION = "ARG_PARAM_CONFIRMATION";

    private Confirmation mConfirmation;

    public ConfirmationFragment() {
        // Required empty public constructor
    }

    public static ConfirmationFragment newInstance(Confirmation confirmation) {
        ConfirmationFragment fragment = new ConfirmationFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM_CONFIRMATION, confirmation);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mConfirmation = (Confirmation) getArguments().getSerializable(ARG_PARAM_CONFIRMATION);
        }
    }

    FragmentConfirmationBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentConfirmationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.textViewName.setText(mConfirmation.getUsername());
        binding.textViewPhone.setText(mConfirmation.getPhone());
        binding.textViewEmail.setText(mConfirmation.getEmail());
        binding.textViewDate.setText(mConfirmation.getDate());
        binding.textViewTime.setText(mConfirmation.getTime());
    }
}