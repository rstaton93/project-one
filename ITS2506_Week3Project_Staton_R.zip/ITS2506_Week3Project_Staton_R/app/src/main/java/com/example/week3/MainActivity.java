package com.example.week3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    Button Reservation;
    Button Menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        Reservation = findViewById(R.id.button);

        Reservation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this, "Reservation has been clicked", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(MainActivity.this, Reservation.class);
                startActivity(intent);

            }

        });


        Menu = findViewById(R.id.button2);

        Menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this, "Menu has been clicked", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                startActivity(intent);

            }

        });


    }

}